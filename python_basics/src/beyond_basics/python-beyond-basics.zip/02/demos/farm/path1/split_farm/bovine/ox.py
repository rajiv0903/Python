from . import common

def ruminate():
    return common.ruminate().upper()

def pull_wagon():
    pass